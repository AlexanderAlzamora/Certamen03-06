from django.contrib import admin


from .models import Mensaje

admin.site.register(Mensaje)#registrar el modelo mensaje en django
# Register your models here.
